ROYAL TOOLS — Starter website
================================
Contents:
- index.html: complete responsive Arabic RTL website with a classic navy-and-gold theme.

Included working tools:
- Uppercase/lowercase and basic bold-style text conversion
- Word/character/line counter
- Text cleaner
- QR generator (uses an external QR service, so internet is required)
- Random password generator
- Percentage calculator
- Approximate age calculator
- Browser-based image compression

Deploy to Cloudflare Pages:
1. Extract this ZIP.
2. Create a GitHub repository and upload index.html to the repository root.
3. In Cloudflare, open Workers & Pages > Create > Pages > Connect to Git.
4. Choose the repository.
5. For a plain static HTML site, leave build command empty and set the output directory to / (or the repository root, as the dashboard prompts).
6. Deploy.

Notes:
- This is a starter version; the English-language toggle is a placeholder.
- QR generation uses an external service.
- Check all features and privacy/legal requirements before public launch.
